import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymemt',
  templateUrl: './paymemt.component.html',
  styleUrls: ['./paymemt.component.css']
})
export class PaymemtComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

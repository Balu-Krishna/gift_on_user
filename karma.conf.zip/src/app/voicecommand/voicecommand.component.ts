import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voicecommand',
  templateUrl: './voicecommand.component.html',
  styleUrls: ['./voicecommand.component.css']
})
export class VoicecommandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

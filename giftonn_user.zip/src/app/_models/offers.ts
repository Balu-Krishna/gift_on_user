export interface offersInterface{
        _id: number;
        dealImage:string;
    }